package com.example.server_Lyav21;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {
    // Пустой контроллер, Spring сам найдет static/index.html
}