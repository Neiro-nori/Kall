package com.example.server_Lyav21;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    private String password; // Поле для пароля
    private String name;     // Поле для имени
    private String email;    // Поле для email

    @ElementCollection
    private List<Post> posts;

    @ElementCollection
    private List<ProductItem> cart;      // Корзина

    @ElementCollection
    private List<ProductItem> favorites; // Избранное

    public User() {
        this.posts = new ArrayList<>();
        this.cart = new ArrayList<>();
        this.favorites = new ArrayList<>();
    }

    public User(String username, String password, String name, String email) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.posts = new ArrayList<>();
        this.cart = new ArrayList<>();
        this.favorites = new ArrayList<>();
    }

    // Геттеры и сеттеры для ID и новых полей
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public List<Post> getPosts() { return posts; }
    public void setPosts(List<Post> posts) { this.posts = posts; }

    public List<ProductItem> getCart() { return cart; }
    public void setCart(List<ProductItem> cart) { this.cart = cart; }

    public List<ProductItem> getFavorites() { return favorites; }
    public void setFavorites(List<ProductItem> favorites) { this.favorites = favorites; }

    // Класс товара для корзины и избранного
    @Embeddable
    public static class ProductItem {
        private String id;
        private String name;
        private int price;
        private String imageUrl;

        public ProductItem() {}

        public ProductItem(String id, String name, int price, String imageUrl) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.imageUrl = imageUrl;
        }

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public int getPrice() { return price; }
        public void setPrice(int price) { this.price = price; }

        public String getImageUrl() { return imageUrl; }
        public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    }

    @Embeddable
    public static class Post {
        private String description;
        private String imageUrl;

        public Post() {}

        public Post(String description, String imageUrl) {
            this.description = description;
            this.imageUrl = imageUrl;
        }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public String getImageUrl() { return imageUrl; }
        public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    }
}