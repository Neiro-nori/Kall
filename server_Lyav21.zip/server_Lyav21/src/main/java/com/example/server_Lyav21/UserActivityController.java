package com.example.server_Lyav21;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserActivityController {

    @Autowired
    private UserRepository userRepository;

    // Регистрация нового пользователя
    @PostMapping
    public ResponseEntity<?> registerUser(@RequestBody User newUser) {
        Optional<User> existingUser = userRepository.findByUsername(newUser.getUsername());
        if (existingUser.isPresent()) {
            return ResponseEntity.badRequest().body("Пользователь с таким логином уже существует!");
        }
        User savedUser = userRepository.save(newUser);
        return ResponseEntity.ok(savedUser);
    }

    // Вход (проверка логина и пароля)
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User loginData) {
        Optional<User> userOpt = userRepository.findByUsername(loginData.getUsername());
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            // Простейшая проверка пароля
            if (user.getPassword().equals(loginData.getPassword())) {
                return ResponseEntity.ok(user);
            } else {
                return ResponseEntity.status(401).body("Неверный пароль!");
            }
        }
        return ResponseEntity.status(404).body("Пользователь не найден!");
    }

    // Получение данных пользователя (например, корзины)
    @GetMapping("/{username}")
    public ResponseEntity<?> getUser(@PathVariable String username) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            return ResponseEntity.ok(userOpt.get());
        }
        return ResponseEntity.status(404).body("Пользователь не найден");
    }

    // Добавление товара в корзину
    @PostMapping("/{username}/cart")
    public ResponseEntity<?> addToCart(@PathVariable String username, @RequestBody User.ProductItem item) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.getCart().add(item);
            userRepository.save(user); // Сохраняем изменения в БД
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(404).body("Пользователь не найден");
    }

    // Удаление конкретного товара из корзины по его индексу в списке
    @DeleteMapping("/{username}/cart/index/{index}")
    public ResponseEntity<?> removeFromCartByIndex(@PathVariable String username, @PathVariable int index) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (index >= 0 && index < user.getCart().size()) {
                user.getCart().remove(index);
                userRepository.save(user); // Сохраняем обновленный список в БД
            }
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(404).body("Пользователь не найден");
    }

    // Очистка всей корзины при заказе
    @DeleteMapping("/{username}/cart")
    public ResponseEntity<?> clearCart(@PathVariable String username) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.getCart().clear();
            userRepository.save(user);
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(404).body("Пользователь не найден");
    }

    // Добавление / удаление из избранного
    @PostMapping("/{username}/favorites")
    public ResponseEntity<?> toggleFavorite(@PathVariable String username, @RequestBody User.ProductItem item) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();

            // Проверяем, есть ли уже товар в избранном, чтобы удалять при повторном клике
            boolean exists = user.getFavorites().stream().anyMatch(i -> i.getId().equals(item.getId()));
            if (exists) {
                user.getFavorites().removeIf(i -> i.getId().equals(item.getId()));
            } else {
                user.getFavorites().add(item);
            }

            userRepository.save(user); // Сохраняем в БД
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(404).body("Пользователь не найден");
    }

    // Удаление конкретного товара из избранного по его индексу в списке
    @DeleteMapping("/{username}/favorites/index/{index}")
    public ResponseEntity<?> removeFromFavoritesByIndex(@PathVariable String username, @PathVariable int index) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (index >= 0 && index < user.getFavorites().size()) {
                user.getFavorites().remove(index);
                userRepository.save(user); // Сохраняем обновленный список в БД
            }
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(404).body("Пользователь не найден");
    }
}