package com.example.server_Lyav21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerLyav21Application {

	public static void main(String[] args) {
		SpringApplication.run(ServerLyav21Application.class, args);
	}

}
