package com.example.server_Lyav21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerLyav21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
